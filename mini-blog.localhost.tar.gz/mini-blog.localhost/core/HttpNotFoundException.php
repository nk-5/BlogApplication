<?php

class HttpNotFoundException extends Exception{};