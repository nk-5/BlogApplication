<?php

class UnauthorizedActionExeption extends Exception{};